# Load necessary libraries
library(affy)  # For reading .CEL files
library(hgu133plus2.db)  # For the hgu133plus2 platform
library(limma)
library(biomaRt)
library(clusterProfiler)
library(org.Hs.eg.db)  # For human data annotation
library(DOSE)  # For enrichment analysis
library(annotate)  # For mapping probe IDs to gene symbols

annotateNDAffy <- function(cel_files_path, group, species = "hsapiens_gene_ensembl", pval_cutoff = 0.05, logFC_cutoff = 1, make_plots = TRUE) {

  cat("Loading .CEL files from the directory...\n")
  affy_data <- ReadAffy(celfile.path = cel_files_path)

  # Background correction, normalization, and summarization using RMA
  cat("Performing background correction, normalization, and summarization using RMA...\n")
  eset <- rma(affy_data)

  # Extract expression matrix from the ExpressionSet object
  expression_data <- exprs(eset)
  cat("Processed expression data dimensions:", dim(expression_data), "\n")

  # Step 2: Create a design matrix for linear modeling
  cat("Creating design matrix for group factors...\n")
  design <- model.matrix(~ group)
  print(design)

  # Step 3: Perform differential expression analysis using limma
  cat("Fitting linear models for differential expression analysis...\n")
  fit <- lmFit(expression_data, design)
  fit <- eBayes(fit)
  topTable <- topTable(fit, coef = 2, adjust = "BH", number = Inf)

  # Step 4: Filter significant genes (e.g., FDR < pval_cutoff and logFC > logFC_cutoff)
  cat("Filtering significant genes based on p-value and log fold change cutoffs...\n")
  significant_genes <- topTable[topTable$adj.P.Val < pval_cutoff & abs(topTable$logFC) > logFC_cutoff,]
  cat("Number of significant genes found:", nrow(significant_genes), "\n")

  # Step 5: Map probe IDs to gene symbols using the hgu133plus2 annotation package
  cat("Mapping probe IDs to gene symbols using hgu133plus2.db...\n")
  gene_symbols <- getSYMBOL(rownames(significant_genes), "hgu133plus2.db")
  significant_genes$Gene_Symbol <- gene_symbols

  # Remove entries with missing gene symbols
  significant_genes <- significant_genes[!is.na(significant_genes$Gene_Symbol), ]
  gene_list <- significant_genes$Gene_Symbol

  # Step 6: Use biomaRt to annotate the genes with verbose output
  cat("Annotating significant genes using biomaRt...\n")
  mart <- useMart("ensembl", dataset = species)
  gene_annotations <- getBM(
    attributes = c("ensembl_gene_id", "external_gene_name", "description"),
    filters = "external_gene_name",
    values = gene_list,
    mart = mart
  )
  cat("Gene annotations retrieved:\n")
  print(head(gene_annotations))

  # Merge DGE results with annotations
  annotated_results <- merge(significant_genes, gene_annotations, by.x = "Gene_Symbol", by.y = "external_gene_name")
  rownames(annotated_results) <- annotated_results$Gene_Symbol

  # Step 7: Perform GO enrichment analysis using clusterProfiler with gene symbols
  cat("Performing GO enrichment analysis...\n")
  ego <- enrichGO(gene = gene_list,
                  OrgDb = org.Hs.eg.db,  # Change based on species
                  keyType = "SYMBOL",    # Using gene symbols
                  ont = "ALL",           # Enrich for all GO categories
                  pAdjustMethod = "BH",
                  qvalueCutoff = pval_cutoff,
                  readable = TRUE)

  # Step 8: Perform KEGG enrichment analysis
  cat("Performing KEGG enrichment analysis...\n")
  kegg <- enrichKEGG(gene = gene_list,
                     organism = 'hsa',  # Adjust for other species if needed
                     pvalueCutoff = pval_cutoff)

  # Step 9: Optional: Create a volcano plot of differential expression results
  if (make_plots) {
    cat("Creating a volcano plot of differential expression results...\n")
    ggplot(topTable, aes(x = logFC, y = -log10(adj.P.Val))) +
      geom_point(aes(color = adj.P.Val < pval_cutoff & abs(logFC) > logFC_cutoff)) +
      scale_color_manual(values = c("grey", "red")) +
      labs(title = "Volcano Plot of Differentially Expressed Genes", x = "Log Fold Change", y = "-log10(adj.P.Val)") +
      theme_minimal()
  }

  # Step 10: Create a detailed results list
  results_list <- list(
    DGE_results = topTable,
    Annotated_DGE_results = annotated_results,
    GO_enrichment = ego,
    KEGG_enrichment = kegg
  )

  # Return the final results
  return(results_list)
}
