# NEURAL EPILEPTOTRANSCRIPTOMIC ADVANCEMENT Proprietary Software
# © 2024 NEURAL EPILEPTOTRANSCRIPTOMIC ADVANCEMENT. All rights reserved.
#
# This software is licensed under the NEURAL EPILEPTOTRANSCRIPTOMIC ADVANCEMENT Software License Agreement.
# You may not use, modify, or distribute this software except in compliance with the license.
# Please refer to the LICENSE file for the full terms of the license.



annotateNDAffy <- function(cel_files_path, group, species = "hsapiens_gene_ensembl", pval_cutoff = 0.05, logFC_cutoff = 1, make_plots = TRUE) {

  cat("Loading .CEL files from the directory...\n")
  affy_data <- ReadAffy(celfile.path = cel_files_path)

  cat("Performing background correction, normalization, and summarization using RMA...\n")
  eset <- rma(affy_data)

  expression_data <- exprs(eset)
  cat("Processed expression data dimensions:", dim(expression_data), "\n")

  cat("Creating design matrix for group factors...\n")
  design <- model.matrix(~ group)
  print(design)

  cat("Fitting linear models for differential expression analysis...\n")
  fit <- lmFit(expression_data, design)
  fit <- eBayes(fit)
  topTable <- topTable(fit, coef = 2, adjust = "BH", number = Inf)

  cat("Filtering significant genes based on p-value and log fold change cutoffs...\n")
  significant_genes <- topTable[topTable$adj.P.Val < pval_cutoff & abs(topTable$logFC) > logFC_cutoff,]
  cat("Number of significant genes found:", nrow(significant_genes), "\n")

  cat("Mapping probe IDs to gene symbols using hgu133plus2.db...\n")
  gene_symbols <- getSYMBOL(rownames(significant_genes), "hgu133plus2.db")
  significant_genes$Gene_Symbol <- gene_symbols

  significant_genes <- significant_genes[!is.na(significant_genes$Gene_Symbol), ]
  gene_list <- significant_genes$Gene_Symbol

  cat("Annotating significant genes using biomaRt...\n")
  mart <- useMart("ensembl", dataset = species)
  gene_annotations <- getBM(
    attributes = c("ensembl_gene_id", "external_gene_name", "description"),
    filters = "external_gene_name",
    values = gene_list,
    mart = mart
  )
  cat("Gene annotations retrieved:\n")
  print(head(gene_annotations))

  annotated_results <- merge(significant_genes, gene_annotations, by.x = "Gene_Symbol", by.y = "external_gene_name")
  rownames(annotated_results) <- annotated_results$Gene_Symbol

  cat("Performing GO enrichment analysis...\n")
  ego <- enrichGO(gene = gene_list,
                  OrgDb = org.Hs.eg.db,
                  keyType = "SYMBOL",
                  ont = "ALL",
                  pAdjustMethod = "BH",
                  qvalueCutoff = pval_cutoff,
                  readable = TRUE)

  cat("Performing KEGG enrichment analysis...\n")
  kegg <- enrichKEGG(gene = gene_list,
                     organism = 'hsa',
                     pvalueCutoff = pval_cutoff)

  if (make_plots) {
    cat("Creating a volcano plot of differential expression results...\n")
    ggplot(topTable, aes(x = logFC, y = -log10(adj.P.Val))) +
      geom_point(aes(color = adj.P.Val < pval_cutoff & abs(logFC) > logFC_cutoff)) +
      scale_color_manual(values = c("grey", "red")) +
      labs(title = "Volcano Plot of Differentially Expressed Genes", x = "Log Fold Change", y = "-log10(adj.P.Val)") +
      theme_minimal()
  }

  results_list <- list(
    DGE_results = topTable,
    Annotated_DGE_results = annotated_results,
    GO_enrichment = ego,
    KEGG_enrichment = kegg
  )

  return(results_list)
}


annotateNDAgilent <- function(data_path, group, is_two_color = FALSE, species = "hsapiens_gene_ensembl", pval_cutoff = 0.05, logFC_cutoff = 1, make_plots = TRUE, visualize_heatmap = TRUE) {

  cat("Loading Agilent microarray data...\n")
  if (is_two_color) {

    cat("Processing two-color Agilent data...\n")
    files <- list.files(path = data_path, pattern = "*.txt$", full.names = TRUE)
    agilent_data <- read.maimages(files, source = "agilent", green.only = FALSE)  # For two-color arrays
  } else {

    cat("Processing one-color Agilent data...\n")
    files <- list.files(path = data_path, pattern = "*.txt$", full.names = TRUE)
    agilent_data <- read.maimages(files, source = "agilent", green.only = TRUE)  # For one-color arrays
  }

  cat("Performing background correction and normalization...\n")
  agilent_data <- backgroundCorrect(agilent_data, method = "normexp")  # Background correction using normexp
  agilent_data <- normalizeBetweenArrays(agilent_data, method = "quantile")  # Quantile normalization

  cat("Creating design matrix for group factors...\n")
  design <- model.matrix(~ group)
  print(design)

  cat("Fitting linear models for differential expression analysis...\n")
  fit <- lmFit(agilent_data, design)
  fit <- eBayes(fit)
  topTable <- topTable(fit, coef = 2, adjust = "BH", number = Inf)

  cat("Filtering significant genes based on p-value and log fold change cutoffs...\n")
  significant_genes <- topTable[topTable$adj.P.Val < pval_cutoff & abs(topTable$logFC) > logFC_cutoff,]
  cat("Number of significant genes found:", nrow(significant_genes), "\n")

  cat("Mapping Agilent probe IDs to gene symbols...\n")
  probe_ids <- rownames(significant_genes)
  gene_symbols <- getSYMBOL(probe_ids, "agilent.db")
  significant_genes$Gene_Symbol <- gene_symbols

  significant_genes <- significant_genes[!is.na(significant_genes$Gene_Symbol), ]
  gene_list <- significant_genes$Gene_Symbol

  cat("Annotating significant genes using biomaRt...\n")
  mart <- useMart("ensembl", dataset = species)
  gene_annotations <- getBM(
    attributes = c("ensembl_gene_id", "external_gene_name", "description"),
    filters = "external_gene_name",
    values = gene_list,
    mart = mart
  )

  cat("Performing GO and KEGG enrichment analysis...\n")
  ego <- enrichGO(gene = gene_list, OrgDb = org.Hs.eg.db, keyType = "SYMBOL", ont = "ALL", pAdjustMethod = "BH", qvalueCutoff = pval_cutoff, readable = TRUE)
  kegg <- enrichKEGG(gene = gene_list, organism = 'hsa', pvalueCutoff = pval_cutoff)

  if (make_plots) {
    cat("Creating a volcano plot of differential expression results...\n")
    ggplot(topTable, aes(x = logFC, y = -log10(adj.P.Val))) +
      geom_point(aes(color = adj.P.Val < pval_cutoff & abs(logFC) > logFC_cutoff)) +
      scale_color_manual(values = c("grey", "red")) +
      labs(title = "Volcano Plot of Differentially Expressed Genes", x = "Log Fold Change", y = "-log10(adj.P.Val)") +
      theme_minimal()
  }

  if (visualize_heatmap) {
    cat("Creating heatmap of significant genes...\n")
    top_genes <- rownames(significant_genes)[1:min(50, nrow(significant_genes))]
    pheatmap(log2(agilent_data$E[top_genes, ] + 1), cluster_rows = TRUE, cluster_cols = TRUE,
             show_rownames = TRUE, show_colnames = TRUE,
             main = "Top 50 Differentially Expressed Genes")
  }

  results_list <- list(
    DGE_results = topTable,
    Annotated_DGE_results = significant_genes,
    GO_enrichment = ego,
    KEGG_enrichment = kegg
  )

  return(results_list)
}


annotateNDCounts <- function(count_data, group, species = "hsapiens_gene_ensembl", pval_cutoff = 0.05, logFC_cutoff = 1, make_plots = TRUE, visualize_heatmap = TRUE) {

  cat("Starting DGE analysis with the following parameters:\n")
  cat("Species:", species, "\n")
  cat("p-value cutoff:", pval_cutoff, "\n")
  cat("log fold change cutoff:", logFC_cutoff, "\n")

  cat("Preparing data for differential expression analysis...\n")
  dge <- DGEList(counts = count_data, group = group)

  cat("Normalizing counts using TMM (trimmed mean of M-values) normalization...\n")
  dge <- calcNormFactors(dge)
  cat("Normalization factors applied:\n")
  print(dge$samples$norm.factors)

  cat("Creating design matrix based on group factors...\n")
  design <- model.matrix(~ group)
  print(design)

  cat("Estimating dispersions to account for biological variability...\n")
  dge <- estimateDisp(dge, design)
  cat("Estimated dispersions:\n")
  print(dge$common.dispersion)

  cat("Fitting GLM model and performing likelihood ratio tests...\n")
  fit <- glmQLFit(dge, design)
  qlf <- glmQLFTest(fit, coef = 2)
  topTable <- topTags(qlf, n = Inf)$table

  cat("Filtering significant genes based on p-value and log fold change cutoffs...\n")
  significant_genes <- topTable[topTable$FDR < pval_cutoff & abs(topTable$logFC) > logFC_cutoff,]
  cat("Number of significant genes found:", nrow(significant_genes), "\n")
  gene_list <- rownames(significant_genes)  # Extract gene symbols or IDs

  if (make_plots) {
    cat("Creating a volcano plot of differential expression results...\n")
    ggplot(topTable, aes(x = logFC, y = -log10(FDR))) +
      geom_point(aes(color = FDR < pval_cutoff & abs(logFC) > logFC_cutoff)) +
      scale_color_manual(values = c("grey", "red")) +
      labs(title = "Volcano Plot of Differentially Expressed Genes", x = "Log Fold Change", y = "-log10(FDR)") +
      theme_minimal()
  }

  if (visualize_heatmap) {
    cat("Creating heatmap of significant genes...\n")
    top_genes <- rownames(significant_genes)[1:min(50, nrow(significant_genes))]
    pheatmap(log2(count_data[top_genes, ] + 1), cluster_rows = TRUE, cluster_cols = TRUE,
             show_rownames = TRUE, show_colnames = TRUE,
             main = "Top 50 Differentially Expressed Genes")
  }

  cat("Annotating significant genes using biomaRt...\n")
  mart <- useMart("ensembl", dataset = species)
  gene_annotations <- getBM(
    attributes = c("ensembl_gene_id", "external_gene_name", "description", "go_id", "kegg_enzyme"),
    filters = "ensembl_gene_id",
    values = gene_list,
    mart = mart
  )
  cat("Gene annotations retrieved:\n")
  print(head(gene_annotations))

  annotated_results <- merge(significant_genes, gene_annotations, by.x = "row.names", by.y = "ensembl_gene_id")
  rownames(annotated_results) <- annotated_results$external_gene_name

  cat("Performing GO enrichment analysis...\n")
  ego <- enrichGO(gene = gene_list,
                  OrgDb = org.Hs.eg.db,  # Change based on species
                  keyType = "ENSEMBL",
                  ont = "ALL",  # Enrich for all GO categories: BP, MF, and CC
                  pAdjustMethod = "BH",
                  qvalueCutoff = pval_cutoff,
                  readable = TRUE)

  cat("Performing KEGG enrichment analysis...\n")
  kegg <- enrichKEGG(gene = gene_list,
                     organism = 'hsa',  # Adjust for other species
                     pvalueCutoff = pval_cutoff)

  cat("GO Enrichment Results Summary:\n")
  print(summary(ego))

  cat("KEGG Enrichment Results Summary:\n")
  print(summary(kegg))

  results_list <- list(
    DGE_results = topTable,
    Annotated_DGE_results = annotated_results,
    GO_enrichment = ego,
    KEGG_enrichment = kegg
  )

  return(results_list)
}


annotateNDIDAT <- function(idat_path, group, species = "hsapiens_gene_ensembl", pval_cutoff = 0.05, logFC_cutoff = 1, make_plots = TRUE, visualize_heatmap = TRUE) {

  cat("Loading Illumina IDAT files...\n")
  idat_files <- list.files(path = idat_path, pattern = "*.idat$", full.names = TRUE)
  raw_data <- readIDAT(idat_files)

  cat("Preprocessing data with lumi...\n")
  lumi_data <- lumiR.idat(idat_path)

  cat("Performing variance stabilization and quantile normalization...\n")
  norm_data <- lumiExpresso(lumi_data, bg.correct = TRUE, variance.stabilize = TRUE, normalize.param = list(method = "quantile"))

  cat("Creating design matrix for group factors...\n")
  design <- model.matrix(~ group)
  print(design)

  cat("Fitting linear models for differential expression analysis...\n")
  fit <- lmFit(norm_data, design)
  fit <- eBayes(fit)
  topTable <- topTable(fit, coef = 2, adjust = "BH", number = Inf)

  cat("Filtering significant genes based on p-value and log fold change cutoffs...\n")
  significant_genes <- topTable[topTable$adj.P.Val < pval_cutoff & abs(topTable$logFC) > logFC_cutoff,]
  cat("Number of significant genes found:", nrow(significant_genes), "\n")

  cat("Mapping Illumina probe IDs to gene symbols...\n")
  gene_symbols <- getSYMBOL(rownames(significant_genes), "illuminaHumanv4.db")
  significant_genes$Gene_Symbol <- gene_symbols

  significant_genes <- significant_genes[!is.na(significant_genes$Gene_Symbol), ]
  gene_list <- significant_genes$Gene_Symbol

  cat("Annotating significant genes using biomaRt...\n")
  mart <- useMart("ensembl", dataset = species)
  gene_annotations <- getBM(
    attributes = c("ensembl_gene_id", "external_gene_name", "description"),
    filters = "external_gene_name",
    values = gene_list,
    mart = mart
  )

  cat("Performing GO and KEGG enrichment analysis...\n")
  ego <- enrichGO(gene = gene_list, OrgDb = org.Hs.eg.db, keyType = "SYMBOL", ont = "ALL", pAdjustMethod = "BH", qvalueCutoff = pval_cutoff, readable = TRUE)
  kegg <- enrichKEGG(gene = gene_list, organism = 'hsa', pvalueCutoff = pval_cutoff)

  if (make_plots) {
    ggplot(topTable, aes(x = logFC, y = -log10(adj.P.Val))) +
      geom_point(aes(color = adj.P.Val < pval_cutoff & abs(logFC) > logFC_cutoff)) +
      labs(title = "Volcano Plot", x = "Log Fold Change", y = "-log10(adj.P.Val)")
  }
  if (visualize_heatmap) {
    top_genes <- rownames(significant_genes)[1:min(50, nrow(significant_genes))]
    pheatmap(log2(norm_data[top_genes, ] + 1), cluster_rows = TRUE, cluster_cols = TRUE, main = "Top 50 Differentially Expressed Genes")
  }

  results_list <- list(
    DGE_results = topTable,
    Annotated_DGE_results = significant_genes,
    GO_enrichment = ego,
    KEGG_enrichment = kegg
  )

  return(results_list)
}

annotateNDOligo <- function(cel_path, group, species = "hsapiens_gene_ensembl", pval_cutoff = 0.05, logFC_cutoff = 1, make_plots = TRUE, visualize_heatmap = TRUE) {

  cat("Loading CEL files for oligo-based microarray data...\n")
  cel_files <- list.celfiles(cel_path, full.names = TRUE)
  oligo_data <- read.celfiles(cel_files)

  cat("Preprocessing data with RMA normalization...\n")
  norm_data <- rma(oligo_data)

  expression_data <- exprs(norm_data)
  cat("Processed expression data dimensions:", dim(expression_data), "\n")

  cat("Creating design matrix for group factors...\n")
  design <- model.matrix(~ group)
  print(design)

  cat("Fitting linear models for differential expression analysis...\n")
  fit <- lmFit(expression_data, design)
  fit <- eBayes(fit)
  topTable <- topTable(fit, coef = 2, adjust = "BH", number = Inf)

  cat("Filtering significant genes based on p-value and log fold change cutoffs...\n")
  significant_genes <- topTable[topTable$adj.P.Val < pval_cutoff & abs(topTable$logFC) > logFC_cutoff,]
  cat("Number of significant genes found:", nrow(significant_genes), "\n")

  cat("Mapping oligo probe IDs to gene symbols...\n")
  probe_ids <- rownames(significant_genes)
  gene_symbols <- getSYMBOL(probe_ids, "hugene10sttranscriptcluster.db")
  significant_genes$Gene_Symbol <- gene_symbols

  significant_genes <- significant_genes[!is.na(significant_genes$Gene_Symbol), ]
  gene_list <- significant_genes$Gene_Symbol

  cat("Annotating significant genes using biomaRt...\n")
  mart <- useMart("ensembl", dataset = species)
  gene_annotations <- getBM(
    attributes = c("ensembl_gene_id", "external_gene_name", "description"),
    filters = "external_gene_name",
    values = gene_list,
    mart = mart
  )

  cat("Performing GO and KEGG enrichment analysis...\n")
  ego <- enrichGO(gene = gene_list, OrgDb = org.Hs.eg.db, keyType = "SYMBOL", ont = "ALL", pAdjustMethod = "BH", qvalueCutoff = pval_cutoff, readable = TRUE)
  kegg <- enrichKEGG(gene = gene_list, organism = 'hsa', pvalueCutoff = pval_cutoff)

  if (make_plots) {
    cat("Creating a volcano plot of differential expression results...\n")
    ggplot(topTable, aes(x = logFC, y = -log10(adj.P.Val))) +
      geom_point(aes(color = adj.P.Val < pval_cutoff & abs(logFC) > logFC_cutoff)) +
      scale_color_manual(values = c("grey", "red")) +
      labs(title = "Volcano Plot of Differentially Expressed Genes", x = "Log Fold Change", y = "-log10(adj.P.Val)") +
      theme_minimal()
  }

  if (visualize_heatmap) {
    cat("Creating heatmap of significant genes...\n")
    top_genes <- rownames(significant_genes)[1:min(50, nrow(significant_genes))]
    pheatmap(log2(expression_data[top_genes, ] + 1), cluster_rows = TRUE, cluster_cols = TRUE,
             show_rownames = TRUE, show_colnames = TRUE,
             main = "Top 50 Differentially Expressed Genes")
  }

  results_list <- list(
    DGE_results = topTable,
    Annotated_DGE_results = significant_genes,
    GO_enrichment = ego,
    KEGG_enrichment = kegg
  )

  return(results_list)
}
