annotateNDIDAT <- function(idat_path, group, species = "hsapiens_gene_ensembl", pval_cutoff = 0.05, logFC_cutoff = 1, make_plots = TRUE, visualize_heatmap = TRUE) {

  cat("Loading Illumina IDAT files...\n")
  idat_files <- list.files(path = idat_path, pattern = "*.idat$", full.names = TRUE)
  raw_data <- readIDAT(idat_files)

  # Step 2: Preprocess the data using lumi
  cat("Preprocessing data with lumi...\n")
  lumi_data <- lumiR.idat(idat_path)

  # Step 3: Normalize the data
  cat("Performing variance stabilization and quantile normalization...\n")
  norm_data <- lumiExpresso(lumi_data, bg.correct = TRUE, variance.stabilize = TRUE, normalize.param = list(method = "quantile"))

  # Step 4: Create a design matrix for linear modeling
  cat("Creating design matrix for group factors...\n")
  design <- model.matrix(~ group)
  print(design)

  # Step 5: Perform differential expression analysis using limma
  cat("Fitting linear models for differential expression analysis...\n")
  fit <- lmFit(norm_data, design)
  fit <- eBayes(fit)
  topTable <- topTable(fit, coef = 2, adjust = "BH", number = Inf)

  # Step 6: Filter significant genes
  cat("Filtering significant genes based on p-value and log fold change cutoffs...\n")
  significant_genes <- topTable[topTable$adj.P.Val < pval_cutoff & abs(topTable$logFC) > logFC_cutoff,]
  cat("Number of significant genes found:", nrow(significant_genes), "\n")

  # Step 7: Map probe IDs to gene symbols
  cat("Mapping Illumina probe IDs to gene symbols...\n")
  gene_symbols <- getSYMBOL(rownames(significant_genes), "illuminaHumanv4.db")
  significant_genes$Gene_Symbol <- gene_symbols

  # Remove entries with missing gene symbols
  significant_genes <- significant_genes[!is.na(significant_genes$Gene_Symbol), ]
  gene_list <- significant_genes$Gene_Symbol

  # Step 8: Annotate significant genes using biomaRt
  cat("Annotating significant genes using biomaRt...\n")
  mart <- useMart("ensembl", dataset = species)
  gene_annotations <- getBM(
    attributes = c("ensembl_gene_id", "external_gene_name", "description"),
    filters = "external_gene_name",
    values = gene_list,
    mart = mart
  )

  # Step 9: Perform GO and KEGG enrichment using clusterProfiler
  cat("Performing GO and KEGG enrichment analysis...\n")
  ego <- enrichGO(gene = gene_list, OrgDb = org.Hs.eg.db, keyType = "SYMBOL", ont = "ALL", pAdjustMethod = "BH", qvalueCutoff = pval_cutoff, readable = TRUE)
  kegg <- enrichKEGG(gene = gene_list, organism = 'hsa', pvalueCutoff = pval_cutoff)

  # Optional: Create volcano plot and heatmap
  if (make_plots) {
    ggplot(topTable, aes(x = logFC, y = -log10(adj.P.Val))) +
      geom_point(aes(color = adj.P.Val < pval_cutoff & abs(logFC) > logFC_cutoff)) +
      labs(title = "Volcano Plot", x = "Log Fold Change", y = "-log10(adj.P.Val)")
  }
  if (visualize_heatmap) {
    top_genes <- rownames(significant_genes)[1:min(50, nrow(significant_genes))]
    pheatmap(log2(norm_data[top_genes, ] + 1), cluster_rows = TRUE, cluster_cols = TRUE, main = "Top 50 Differentially Expressed Genes")
  }

  # Return results
  results_list <- list(
    DGE_results = topTable,
    Annotated_DGE_results = significant_genes,
    GO_enrichment = ego,
    KEGG_enrichment = kegg
  )

  return(results_list)
}
