# NEURAL EPILEPTOTRANSCRIPTOMIC ADVANCEMENT Proprietary Software
# © 2024 NEURAL EPILEPTOTRANSCRIPTOMIC ADVANCEMENT. All rights reserved.
#
# This software is licensed under the NEURAL EPILEPTOTRANSCRIPTOMIC ADVANCEMENT Software License Agreement.
# You may not use, modify, or distribute this software except in compliance with the license.
# Please refer to the LICENSE file for the full terms of the license.


.onLoad <- function(libname, pkgname) {
  packageStartupMessage("Welcome to AnnotateDB.")

  required_packages <- c("oligo", "limma", "biomaRt", "clusterProfiler",
                         "org.Hs.eg.db", "DOSE", "ggplot2", "pheatmap",
                         "edgeR", "affy", "hgu133plus2.db", "annotate")

  for (pkg in required_packages) {
    if (!requireNamespace(pkg, quietly = TRUE)) {
      if (pkg %in% c("oligo", "biomaRt", "clusterProfiler", "org.Hs.eg.db",
                     "DOSE", "affy", "hgu133plus2.db", "annotate")) {
        if (!requireNamespace("BiocManager", quietly = TRUE)) {
          install.packages("BiocManager")
        }
        BiocManager::install(pkg)
      } else {
        install.packages(pkg)
      }
    }
  }
}
