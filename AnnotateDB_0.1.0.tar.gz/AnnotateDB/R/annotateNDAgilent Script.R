library(limma)           # For reading and preprocessing Agilent microarray data and DGE analysis
library(biomaRt)         # For gene annotation
library(clusterProfiler) # For GO/KEGG enrichment
library(org.Hs.eg.db)    # For human gene annotations
library(DOSE)            # For enrichment analysis (optional)
library(ggplot2)         # For visualization (optional)
library(pheatmap)        # For heatmap visualization

annotateNDAgilent <- function(data_path, group, is_two_color = FALSE, species = "hsapiens_gene_ensembl", pval_cutoff = 0.05, logFC_cutoff = 1, make_plots = TRUE, visualize_heatmap = TRUE) {

  cat("Loading Agilent microarray data...\n")
  if (is_two_color) {

        cat("Processing two-color Agilent data...\n")
    files <- list.files(path = data_path, pattern = "*.txt$", full.names = TRUE)
    agilent_data <- read.maimages(files, source = "agilent", green.only = FALSE)  # For two-color arrays
  } else {

        cat("Processing one-color Agilent data...\n")
    files <- list.files(path = data_path, pattern = "*.txt$", full.names = TRUE)
    agilent_data <- read.maimages(files, source = "agilent", green.only = TRUE)  # For one-color arrays
  }

  cat("Performing background correction and normalization...\n")
  agilent_data <- backgroundCorrect(agilent_data, method = "normexp")  # Background correction using normexp
  agilent_data <- normalizeBetweenArrays(agilent_data, method = "quantile")  # Quantile normalization

  cat("Creating design matrix for group factors...\n")
  design <- model.matrix(~ group)
  print(design)

  cat("Fitting linear models for differential expression analysis...\n")
  fit <- lmFit(agilent_data, design)
  fit <- eBayes(fit)
  topTable <- topTable(fit, coef = 2, adjust = "BH", number = Inf)

  cat("Filtering significant genes based on p-value and log fold change cutoffs...\n")
  significant_genes <- topTable[topTable$adj.P.Val < pval_cutoff & abs(topTable$logFC) > logFC_cutoff,]
  cat("Number of significant genes found:", nrow(significant_genes), "\n")

  cat("Mapping Agilent probe IDs to gene symbols...\n")
  probe_ids <- rownames(significant_genes)
  gene_symbols <- getSYMBOL(probe_ids, "agilent.db")  # Replace with the appropriate Agilent platform annotation package
  significant_genes$Gene_Symbol <- gene_symbols

  significant_genes <- significant_genes[!is.na(significant_genes$Gene_Symbol), ]
  gene_list <- significant_genes$Gene_Symbol

  cat("Annotating significant genes using biomaRt...\n")
  mart <- useMart("ensembl", dataset = species)
  gene_annotations <- getBM(
    attributes = c("ensembl_gene_id", "external_gene_name", "description"),
    filters = "external_gene_name",
    values = gene_list,
    mart = mart
  )

  cat("Performing GO and KEGG enrichment analysis...\n")
  ego <- enrichGO(gene = gene_list, OrgDb = org.Hs.eg.db, keyType = "SYMBOL", ont = "ALL", pAdjustMethod = "BH", qvalueCutoff = pval_cutoff, readable = TRUE)
  kegg <- enrichKEGG(gene = gene_list, organism = 'hsa', pvalueCutoff = pval_cutoff)

  if (make_plots) {
    cat("Creating a volcano plot of differential expression results...\n")
    ggplot(topTable, aes(x = logFC, y = -log10(adj.P.Val))) +
      geom_point(aes(color = adj.P.Val < pval_cutoff & abs(logFC) > logFC_cutoff)) +
      scale_color_manual(values = c("grey", "red")) +
      labs(title = "Volcano Plot of Differentially Expressed Genes", x = "Log Fold Change", y = "-log10(adj.P.Val)") +
      theme_minimal()
  }

  if (visualize_heatmap) {
    cat("Creating heatmap of significant genes...\n")
    top_genes <- rownames(significant_genes)[1:min(50, nrow(significant_genes))]
    pheatmap(log2(agilent_data$E[top_genes, ] + 1), cluster_rows = TRUE, cluster_cols = TRUE,
             show_rownames = TRUE, show_colnames = TRUE,
             main = "Top 50 Differentially Expressed Genes")
  }

  results_list <- list(
    DGE_results = topTable,
    Annotated_DGE_results = significant_genes,
    GO_enrichment = ego,
    KEGG_enrichment = kegg
  )

  return(results_list)
}
