# Load necessary libraries
library(edgeR)
library(limma)
library(biomaRt)
library(clusterProfiler)
library(org.Hs.eg.db)  # Change for species-specific annotation
library(DOSE)  # For enrichment analysis
library(ggplot2)  # Optional visualization
library(pheatmap) # For heatmap visualization

# Function to perform DGE, quality control, annotation, enrichment, and visualization
annotateNDCounts <- function(count_data, group, species = "hsapiens_gene_ensembl", pval_cutoff = 0.05, logFC_cutoff = 1, make_plots = TRUE, visualize_heatmap = TRUE) {

  # Verbose: Print input parameters for transparency
  cat("Starting DGE analysis with the following parameters:\n")
  cat("Species:", species, "\n")
  cat("p-value cutoff:", pval_cutoff, "\n")
  cat("log fold change cutoff:", logFC_cutoff, "\n")

  # Step 1: Prepare DGEList object for edgeR with verbose details
  cat("Preparing data for differential expression analysis...\n")
  dge <- DGEList(counts = count_data, group = group)

  # Perform normalization and print normalization factors
  cat("Normalizing counts using TMM (trimmed mean of M-values) normalization...\n")
  dge <- calcNormFactors(dge)
  cat("Normalization factors applied:\n")
  print(dge$samples$norm.factors)

  # Step 2: Create design matrix for linear modeling
  cat("Creating design matrix based on group factors...\n")
  design <- model.matrix(~ group)
  print(design)

  # Step 3: Estimate dispersions and provide verbose output
  cat("Estimating dispersions to account for biological variability...\n")
  dge <- estimateDisp(dge, design)
  cat("Estimated dispersions:\n")
  print(dge$common.dispersion)

  # Step 4: Perform differential expression analysis using edgeR and limma
  cat("Fitting GLM model and performing likelihood ratio tests...\n")
  fit <- glmQLFit(dge, design)
  qlf <- glmQLFTest(fit, coef = 2)
  topTable <- topTags(qlf, n = Inf)$table

  # Step 5: Filter significant genes (e.g., FDR < pval_cutoff and logFC > logFC_cutoff)
  cat("Filtering significant genes based on p-value and log fold change cutoffs...\n")
  significant_genes <- topTable[topTable$FDR < pval_cutoff & abs(topTable$logFC) > logFC_cutoff,]
  cat("Number of significant genes found:", nrow(significant_genes), "\n")
  gene_list <- rownames(significant_genes)  # Extract gene symbols or IDs

  # Optional: Visualize results as a volcano plot
  if (make_plots) {
    cat("Creating a volcano plot of differential expression results...\n")
    ggplot(topTable, aes(x = logFC, y = -log10(FDR))) +
      geom_point(aes(color = FDR < pval_cutoff & abs(logFC) > logFC_cutoff)) +
      scale_color_manual(values = c("grey", "red")) +
      labs(title = "Volcano Plot of Differentially Expressed Genes", x = "Log Fold Change", y = "-log10(FDR)") +
      theme_minimal()
  }

  # Optional: Heatmap visualization of the top differentially expressed genes
  if (visualize_heatmap) {
    cat("Creating heatmap of significant genes...\n")
    top_genes <- rownames(significant_genes)[1:min(50, nrow(significant_genes))]
    pheatmap(log2(count_data[top_genes, ] + 1), cluster_rows = TRUE, cluster_cols = TRUE,
             show_rownames = TRUE, show_colnames = TRUE,
             main = "Top 50 Differentially Expressed Genes")
  }

  # Step 6: Use biomaRt to annotate the genes with verbose output
  cat("Annotating significant genes using biomaRt...\n")
  mart <- useMart("ensembl", dataset = species)
  gene_annotations <- getBM(
    attributes = c("ensembl_gene_id", "external_gene_name", "description", "go_id", "kegg_enzyme"),
    filters = "ensembl_gene_id",
    values = gene_list,
    mart = mart
  )
  cat("Gene annotations retrieved:\n")
  print(head(gene_annotations))

  # Merge DGE results with annotations
  annotated_results <- merge(significant_genes, gene_annotations, by.x = "row.names", by.y = "ensembl_gene_id")
  rownames(annotated_results) <- annotated_results$external_gene_name

  # Step 7: Perform GO enrichment analysis using clusterProfiler with more options
  cat("Performing GO enrichment analysis...\n")
  ego <- enrichGO(gene = gene_list,
                  OrgDb = org.Hs.eg.db,  # Change based on species
                  keyType = "ENSEMBL",
                  ont = "ALL",  # Enrich for all GO categories: BP, MF, and CC
                  pAdjustMethod = "BH",
                  qvalueCutoff = pval_cutoff,
                  readable = TRUE)

  # Step 8: Perform KEGG enrichment analysis
  cat("Performing KEGG enrichment analysis...\n")
  kegg <- enrichKEGG(gene = gene_list,
                     organism = 'hsa',  # Adjust for other species
                     pvalueCutoff = pval_cutoff)

  # Step 9: Additional verbose enrichment results
  cat("GO Enrichment Results Summary:\n")
  print(summary(ego))

  cat("KEGG Enrichment Results Summary:\n")
  print(summary(kegg))

  # Step 10: Create a detailed results list
  results_list <- list(
    DGE_results = topTable,
    Annotated_DGE_results = annotated_results,
    GO_enrichment = ego,
    KEGG_enrichment = kegg
  )

  # Return the final results
  return(results_list)
}

# Example usage (assuming 'count_data' is a matrix of RNA-seq counts and 'group' is a factor):
# results <- run_DGE_and_Enrichment(count_data = your_count_matrix, group = your_group_factor)
